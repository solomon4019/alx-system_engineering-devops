# Web stack debugging
Project done during **Full Stack Software Engineering studies** at **Holberton School**. It aims to learn about how to debug a webstack.

## Technologies
* Scripts written in Bash 4.3.11(1)
* Tested on Ubuntu 14.04 LTS

## Files

| Filename | Description |
| -------- | ----------- |
| `0-give_me_a_page` | Turns on the Apache server |
